# 🐧 Lava Hop — Penguin's Great Escape

A complete, arcade-style 3D endless road-crossing game built with Three.js and the Web Audio API.

## 🚀 How to Host & Play

This project is completely self-contained and ready to host on any static hosting provider.

### Option 1: Double-Click to Play Locally
- Simply double-click `index.html` in your file explorer to open and play directly in any modern browser (Chrome, Edge, Safari, Firefox).
- All 3D models, textures, animations, and sound effects (including custom voiceover) are self-contained.

### Option 2: Free 1-Click Hosting

#### GitHub Pages
1. Create a new GitHub repository.
2. Upload `index.html` and `death_sound.mp3`.
3. Go to **Settings** > **Pages** > Select `main` branch and click **Save**.
4. Your game will be live at `https://<username>.github.io/<repo-name>/`.

#### Vercel / Netlify / Cloudflare Pages
- Drag and drop this folder onto [Vercel](https://vercel.com) or [Netlify Drop](https://app.netlify.com/drop). It will deploy instantly with a live URL.

#### Itch.io
- Upload `lava-hop-game.zip` as an HTML5 playable game. Set `index.html` as the entrypoint.

#### Local HTTP Server (Optional)
```bash
# Using Python 3:
python3 -m http.server 8080

# Using Node.js:
npx serve .
```
Then visit `http://localhost:8080` in your web browser.

---

## 🎮 Controls

### Desktop
- **⬆️ / W**: Hop Forward (+1 Score)
- **⬇️ / S**: Hop Backward
- **⬅️ / A**: Hop Left
- **➡️ / D**: Hop Right
- **R**: Instant Restart
- **Mouse**: Click upper screen to hop forward, click left/right sides to hop sideways

### Mobile (Touch)
- Responsive on-screen **4-Way D-Pad**
- Full **Swipe Gestures** (swipe up to hop forward)
- **↺ Restart** button
- Fully playable in both **Landscape** and **Portrait** orientations

### Gamepad
- Full support for **D-pad** and **Left Analog Stick**
- **A / B** buttons to restart upon death

---

## 🌋 Features
- **Cute Blocky Penguin**: Custom low-poly character with tiny yellow construction helmet and dynamic squash-and-stretch hopping animations.
- **Molten Lava Hazard**: Floating rocks, volcanic basalt slabs, and drifting logs that carry the player horizontally.
- **Dangerous Traffic & Railway Crossings**: Cars, trucks, and high-speed freight trains with animated blinking red warning lights and bells.
- **Magma Predator**: An idle timeout danger mechanic where an ominous shadow appears and a magma raptor swoops down if you stay still for too long.
- **Near-Miss Slow-Mo**: Barely dodging a car or train triggers cinematic slow motion and combo rewards.
- **Daily Challenge**: Deterministic daily seed (`YYYYMMDD`) giving all players worldwide the same map for the day, with persistent best score tracking.
- **Comedic Audio**: Custom voice reaction on death with Web Audio procedural sound design.
